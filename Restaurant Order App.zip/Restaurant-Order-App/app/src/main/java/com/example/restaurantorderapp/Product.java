// Assuming this is your Product.java class
package com.example.restaurantorderapp;

public class Product {
    private String title;
    private double price;
    private float rating;
    private String image; // URL to the image

    public Product(String title, double price, float rating, String image) {
        this.title = title;
        this.price = price;
        this.rating = rating;
        this.image = image;
    }

    // Constructor for StaffOrders if it only provides title and rating
    public Product(String title, float rating) {
        this.title = title;
        this.rating = rating;
        this.price = 0.0; // Default or irrelevant for staff view
        this.image = null; // Default or irrelevant for staff view
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public double getPrice() {
        return price;
    }

    public float getRating() {
        return rating;
    }

    public String getImage() {
        return image;
    }
}
