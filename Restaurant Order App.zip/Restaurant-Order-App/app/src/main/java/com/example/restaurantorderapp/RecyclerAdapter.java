package com.example.restaurantorderapp; // Ensure this matches your package

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull; // Use support annotation
import android.support.v7.widget.RecyclerView; // Use support library RecyclerView
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast; // Added Toast for the example click listener

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {

    private Context mContext;
    private List<Product> products = new ArrayList<>();
    private int mLayoutResId; // To allow choosing the layout for the item

    // Modified constructor to accept layout resource ID
    public RecyclerAdapter(Context context, List<Product> products, int layoutResId) {
        this.mContext = context;
        this.products = products;
        this.mLayoutResId = layoutResId;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView mTitle, mPrice;
        private ImageView mImageView;
        private RatingBar mRate;
        private LinearLayout mContainer;

        public MyViewHolder(View view) {
            super(view);

            // Ensure these IDs exist in BOTH products_list_item_layout.xml AND staff_order_item_layout.xml
            mTitle = view.findViewById(R.id.product_title);
            mImageView = view.findViewById(R.id.product_image);
            mRate = view.findViewById(R.id.product_rating);
            mPrice = view.findViewById(R.id.product_price);
            mContainer = view.findViewById(R.id.product_container);
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout based on the mLayoutResId passed in the constructor
        View view = LayoutInflater.from(mContext).inflate(mLayoutResId, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Product product = products.get(position);

        holder.mTitle.setText(product.getTitle());
        holder.mRate.setRating(product.getRating());

        // Handle price - only show if it's a valid price (not 0.0 if that's your default for staff orders)
        if (product.getPrice() > 0.0) {
            holder.mPrice.setText("Ksh " + product.getPrice());
            holder.mPrice.setVisibility(View.VISIBLE);
        } else {
            holder.mPrice.setVisibility(View.GONE); // Hide price if not applicable
        }

        // Handle image - only show if image URL is available
        if (product.getImage() != null && !product.getImage().isEmpty()) {
            Glide.with(mContext).load(product.getImage()).into(holder.mImageView);
            holder.mImageView.setVisibility(View.VISIBLE);
        } else {
            holder.mImageView.setVisibility(View.GONE); // Hide image if not available
        }

        holder.mContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Example: What happens when an item is clicked
                // If you have a detailed activity, you can pass data to it.
                Toast.makeText(mContext, "Item: " + product.getTitle() + " clicked!", Toast.LENGTH_SHORT).show();

                // Example for opening a detailed view:
                // Intent intent = new Intent(mContext, DetailedProductsActivity.class);
                // intent.putExtra("title", product.getTitle());
                // intent.putExtra("image", product.getImage());
                // intent.putExtra("rate", product.getRating());
                // intent.putExtra("price", product.getPrice());
                // mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }
}
