package com.example.restaurantorderapp;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class StaffOrderHistory extends AppCompatActivity {

    int staffID;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_order_history);

        staffID = getIntent().getIntExtra("STAFF_ID", -1);

        //LinearLayout OrdersList = (LinearLayout) findViewById(R.id.staffOrdersList);

        //RecyclerView order = new RecyclerView();

      //  for
    }
}


