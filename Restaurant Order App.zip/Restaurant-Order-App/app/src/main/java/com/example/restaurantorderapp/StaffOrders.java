package com.example.restaurantorderapp;

// Use older Android Support Library imports
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull; // Still use support annotation
import android.support.v7.app.AppCompatActivity; // Stick with AppCompatActivity if possible for Toolbar
import android.support.v7.widget.LinearLayoutManager; // Use support library RecyclerView layout manager
import android.support.v7.widget.RecyclerView; // Use support library RecyclerView
import android.support.v7.widget.Toolbar; // Use support library Toolbar (if AppCompatActivity)
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class StaffOrders extends AppCompatActivity { // Keep AppCompatActivity for Toolbar benefits

    // Variable declarations
    private String userEmail;
    private TextView textView;
    private Toolbar mToolbar; // android.support.v7.widget.Toolbar
    private android.support.v7.app.ActionBar mActionBar; // android.support.v7.app.ActionBar
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager manager;
    private RecyclerView.Adapter mAdapter;
    private List<Product> products;
    private ProgressBar progressBar;
    private static final String BASE_URL = "https://lamp.ms.wits.ac.za/home/s2676309/order_retrieval.php";


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.dashboard_menu, menu);
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.staff_order_history); // Corrected: Add semicolon

        mToolbar = findViewById(R.id.dashboard_toolbar);
        progressBar = findViewById(R.id.progressbar);
        setSupportActionBar(mToolbar); // This method is provided by AppCompatActivity
        mActionBar = getSupportActionBar(); // This method is provided by AppCompatActivity

        recyclerView = findViewById(R.id.products_recyclerView);
        // Use LinearLayoutManager for single item per row
        manager = new LinearLayoutManager(StaffOrders.this); // Changed from GridLayoutManager, corrected context
        recyclerView.setLayoutManager(manager);
        products = new ArrayList<>();

        getProducts();
    }

    private void getProducts() {
        progressBar.setVisibility(View.VISIBLE);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, BASE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressBar.setVisibility(View.GONE);

                        try {
                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject object = array.getJSONObject(i);

                                String title = object.getString("title");
                                // Assuming your PHP only returns title and rating for staff orders
                                double rating = object.getDouble("rating");

                                // Convert double to float for Product constructor if needed
                                float newRate = (float) rating; // Direct cast is safer

                                // Using the Product constructor that takes title and rating
                                Product product = new Product(title, newRate);
                                products.add(product);
                            }

                        } catch (Exception e) {
                            e.printStackTrace(); // Log the error for debugging
                            Toast.makeText(StaffOrders.this, "Error parsing data: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }

                        // Assuming RecyclerAdapter can handle the layout ID
                        mAdapter = new RecyclerAdapter(StaffOrders.this, products, R.layout.staff_order_item_layout);
                        recyclerView.setAdapter(mAdapter);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(StaffOrders.this, error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        Volley.newRequestQueue(StaffOrders.this).add(stringRequest); // Corrected context
    }
}